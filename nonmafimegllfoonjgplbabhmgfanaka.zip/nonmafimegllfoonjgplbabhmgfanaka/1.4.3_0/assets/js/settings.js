$(function(){
    request(get_request_uri('/server/settings'));
});
